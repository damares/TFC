<?php

class OEAutoCompleteCreator {

	private $fieldNames = null;

	public function __construct() {
	
		$fieldNames = array();
	
	}
	
	public function createHeaders() {
	
		$html = '';
		
		$html .= '
			<link rel="stylesheet" href="' . $this->getBaseURL() . 'extensions/OntologyEditor/skins/autocomplete/css/autosuggest_inquisitor.css" type="text/css" media="screen" charset="utf-8" />
			<script type="text/javascript" src="' . $this->getBaseURL() . 'extensions/OntologyEditor/skins/autocomplete/autosuggest.js" charset="utf-8"></script>
			';
			
		return $html;
	
	}
	
	public function createAutoCompleteBox($inputFieldId, $value, $scriptName) {
	
		$html = '';
		
		$html .= '
		
			<script type="text/javascript">
				$(document).ready(function() {
					
					var options = {
						script:"' . $scriptName . '",
						varname:"input",
						json:true,
						shownoresults:false,
						maxresults:6,
						callback: function (obj) { }
					};
					var as_json = new bsn.AutoSuggest("' . $inputFieldId . '", options);
				
				});
			</script>';
			
		$html .= '<input style="width: 160px" name="' . $inputFieldId . '" type="text" id="' . $inputFieldId . '" value="' . $value . '" />';
		
		
		return $html;
	
	
	}
	
	private function getBasePath() {
		global $wgTitle, $wgOut;
		$basePath = explode($wgTitle->newMainPage()->getPartialUrl(), $wgTitle->newMainPage()->getFullURL());
		return $basePath[0];
	}
	
	private function getBaseURL() {
		$baseURL = explode('index.php' ,$this->getBasePath());
		return $baseURL[0];
	}


}
