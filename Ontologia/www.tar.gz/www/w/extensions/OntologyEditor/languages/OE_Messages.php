<?php
/**
 * Internationalization file for the Ontology Editor extension
 *
*/

$messages = array();
$imgpath = 

/** English
 */
$messages['en'] = array(
	
	'createclass'                        => 'Create Category',
	'createontology'                     => 'Create Vocabulary',
	'createvocabulary'		     => 'Create Vocabulary',
	'editclass'                          => 'Edit Category',
	'editcategory'			     => 'Edit Category',
	'test'                               => 'Overview',
	'quickedit'			     => '',
        'overview'                           => 'Overview',
	'sf_createclass_properties'          => 'Add New Properties',
	'sf_createclass_properties_existing' => 'Add Existing Properties',
	'sf_createtemplate_displaylabel_opt' => 'Display label (optional):',
	'sf_createclass_namelabel'           => 'Category name:',
	'sf_createontology_namelabel'        => 'Vocabulary name:',
	'sf_createtemplate_propertyname'     => 'Property name:',
	'sf_createclass_ontologylabel'       => 'Vocabulary:',
	'info_classtitle'                    => 'Specify a suitable title for the category, select a vocabulary and optionally associate one or multiple suitable supercategories',
	'info_classinformation'              => 'Specify meta information about the category: SeeAlso (a URL), the synyoms, how to use the category, and an informal description.',
	'info_newproperties'                 => 'Add new properties for the category. Select a suitable datatype from the dropdown menu.',
	'info_existingproperties'            => 'Add an existing property for the category from the dropdown menu.',
	'info_superclasses'                  => 'Select a suitable supercategory for the category.',
	'info_suggestions'                   => 'Before submission, check your category for existing categories where a similarity is detected. It should help to avoid creating redundant categories.',
	'info_ontologyinformation'           => 'Specify a title and an informal description for the vocabulary.',
	'sf_createcategory_makesubclass'  => 'Make this a subcategory of another category (optional):',

	'icon_class_href'                         => '/extensions/OntologyEditor/skins/images/c_blue.ico',
        'icon_instance_href'                      => '/extensions/OntologyEditor/skins/images/e_lg.ico',
        'icon_ontology_href'                      => '/extensions/OntologyEditor/skins/images/v_gold.ico',
        'icon_property_href'                      => '/extensions/OntologyEditor/skins/images/p_violet.ico',

	'icon_del'			=> '/extensions/OntologyEditor/skins/images/delete.png',
	'icon_add'			=> '/extensions/OntologyEditor/skins/images/add.png',

	'icon_bullet_go'		=> '/extensions/OntologyEditor/skins/images/bullet_go.png',

	'icon_folder_explore'		=> '/extensions/OntologyEditor/skins/images/folder_explore.png',

	'icon_cycle'			=> '/extensions/OntologyEditor/skins/images/cycle3.gif',
	

	'properties'                         => 'Properties',
        'propertiesfrom'                     => 'Display properties starting at',
        'elements'                           => 'Elements',
        'elementsfrom'                       => 'Display elements starting at',
	'vocabularies'			=> 'Vocabularies',
	'vocabulariesfrom'		=> 'Display vocabularies starting at',
	'ontocheck_category_error'		=> 'Please specify a category title.',
	'ontocheck_vocabulary_error'	=> 'Please specify a vocabulary.',

	'sf_createcategory_makesubcategory'  => 'Make this a subcategory of another category:',
	'sf_createproperty_proptype'         => 'Type:',
	'sf_createproperty_propname'	     => 'Name:',
        'sf_createtemplate_semanticproperty' => 'Semantic property:',

	'versioning' => 'Versioning',
	'allvocabularies' => 'All Vocabularies',
	'allelements' => 'All Elements',
	'allproperties' => 'All Properties',
	'folkimport' => 'Folksonomy Import',
	'tagcloud' => 'Tag Cloud',
	'oe_setup' => 'OE_Setup',

'createcategorypagetext' => 'The form below enables you to create a new category. This includes the input of a category name and to choose a vocabulary, the category should belong to. Moreover you can give additional information like a related URI (SeeAlso), other terms that represent the concept behind the category (Synonyms), a sentence in which the category is used (Example of Usage) and a description. Then you can tie properties to the category by either creating new ones which also includes selecting a type for these properties or by choosing an already existing one. After that you might select an existing category which is a supercategory of the new one (like Vehicle is a supercategory of Limousine). Clicking on Check Category will provide some constraint checks which should be applied before saving the new category.',

'sf_blank_error'                     => 'cannot be blank',
'sf_vocabulary_error'		=> 'cannot be empty',




'SMW_NS_ONTOLOGY' => 'Vocabulary',
'SMW_NS_ONTOLOGY_TALK' => 'Vocabulary_talk',

#new sidebar
'createclass' => 'Create Category',
'createclass-url' => 'Special:CreateClass',
'createontology' => 'Create Vocabulary',
'createontology-url' => 'Special:CreateOntology',
'createproperty' => 'Create Property',
'createproperty-url' => 'Special:CreateProperty',
#new
'createcategory' => 'Create Category',
'createcategory-url' => 'Special:CreateCategory',
'createvocabulary' => 'Create Vocabulary',
'createvocabulary-url' => 'Special:CreateVocabulary',

#oe_setup

'oe_setuptext' => 'The OntologyEditor was succesfully installed.',

	

#Categories in cycles
'categoriesincycles'         => 'Categories in cycles',
'categoriesincyclespagetext' => 'This page displays categories which are part of a cycle or are a subcategory of another one which is part of a cycle. Due to consistency and functionality, cycles must be avoided.',
#Concepts
'concepts'         => 'Concepts',
'conceptspagetext' => 'This page displays all concepts in this wiki.',
#CategoryHistogram
'categoryhistogram'         => 'Category Histogram',
'categoryhistogrampagetext' => 'This page displays the category histogram. For each letter the categories starting with that letter are counted and the result is displayed horizontally. The size of the bars is normalized using the longest bar as basis. After clicking on one of the letters all the categories starting with that letter will be displayed.',
'categoryhistogramspecificpagetext' => 'This page displays all categories starting with the chosen letter.',
#PropertyHistogram
'propertyhistogram'         => 'Property Histogram',
'propertyhistogrampagetext' => 'This page displays the property histogram. For each letter the properties starting with that letter are counted and the result is displayed horizontally. The size of the bars is normalized using the longest bar as basis. After clicking on one of the letters all the properties starting with that letter will be displayed.',
'propertyhistogramspecificpagetext' => 'This page displays all properties starting with the chosen letter.',
#UnsubcategorizedCategories
'unsubcategorizedcategories'         => 'Unsubcategorized categories',
'unsubcategorizedcategoriespagetext' => 'This page displays all the categories, which do not have any subcategories. These categories may be changed into elements or it might be necessary to subcategorize these categories further.',
#CategoriesWithSimilarPropertySets
'categorieswithsimilarpropertysets'         => 'Categories with similar property sets',
'categorieswithsimilarpropertysetspagetext' => 'This page displays categories with similar property sets. The main list contains the categories under consideration while the sub lists contain the categories, which have a property set similar (at least 50% common properties) to the corresponding category of the main list. The common properties are diplayed in brackets. The equality of a set of properties might be a hint that the categories under consideration are similar and thus be merged.',
#CategoryStatistics
'categorystatistics'         => 'Category Statistics',
'categorystatisticspagetext' => 'This page displays certain figures regarding all the categories in the wiki. The first table provides some explanations to the values calculated. The second table shows the minimum, average and maximum of the calculations using all categories. The third table shows the calculations for each single category. Orange cells indicate that there might be something wrong, e.g, the value equals the minimum or maximum value. Red cells indicate that there is indeed a problem, like a redundant link.',
# Special:CategoryKnowledgeRepair
'categoryknowledgerepair'            => 'CategoryKnowledgeRepair',
'categoryknowledgerepairpagetext'        => 'This page displays some statistics and probable problems regarding categories. Red cells indicate severe problems, orange cells represent an issue which can be dealt with, white cells give general information or indicate that there are no problems.',
'categoryunderinvestigation'=>'Category under investigation: ',
#EntitiesWithSimilarNames
'entitieswithsimilarnames'         => 'Entities with similar names',
'entitieswithsimilarnamespagetext' => 'This page displays entities with similar names. Similar names of entities might be a hint that the entities are representing the same and thus should be merged. Please choose among the following:',
#CategoriesWithRedundantLinks
'categorieswithredundantlinks'         => 'Categories with redundant subcategory relations',
'categorieswithredundantlinkspagetext' => 'This page displays categories with redundant subcategoryOf relations. That means that the category under consideration is a subcategory of two or more other categories which are on the same branch in the category tree. If the category is part of a cycle, redundant links cannot be calculated until the cycle has been resolved. The main list displays the categories under consideration, while the sub lists display all the categories which are supposed to be redundant supercategories. After clicking on "View Relations", all the branches containing the category under consideration will be displayed including the ones supposed to be redundant.',
'categorieswithredundantpathspagetext' => 'This page displays all the branches containing the chosen category including the ones which are supposed to be redundant. After clicking on "Remove Redundancy" the corresponding branch will be deleted. ',
#ImportVocabulary
'importvocabularyresults'         => 'Import Vocabulary Results',
'importvocabularyresultspagetext' => 'This page displays the results of the vocabulary import.',
'importvocabulary'         => 'Import Vocabulary',
'importvocabularypagetext' => 'This page enables the import of a vocabulary. ATTENTION! This can take some time!',
#VocabularyExport
'vocabularyexport'         => 'Vocabularyexport',
'vocabularyexportpagetext' => 'This page provides a automatically generated vocabulary in OWL.',
# Export
'export'            => 'Export pages',
# Special:SpecialPages
'specialpages-group-knowledgerepair'        => 'Knowledge Repair',
#'specialpages-group-oe_group'        => 'Knowledge Repair',
# Metadata in edit box
'repair'			=> 'Repair',
#LocalentityAbbreviation
'localowlentityabreviation' => 'SMWIBK'



);


