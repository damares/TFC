<?php
/**
 * @file
 * @ingroup SpecialPage
 * @author Stephan W�lger
 */

class CategoryKnowledgeRepair extends SpecialPage {

	function CategoryKnowledgeRepair() {
                SpecialPage::SpecialPage('CategoryKnowledgeRepair');
                wfLoadExtensionMessages('OntologyEditor');
        }

	function execute( $par=null )
	{
		wfSpecialCategoryKnowledgeRepair($par);
	}


}


function wfSpecialCategoryKnowledgeRepair( $par=null ) {
	global $wgOut, $wgRequest,$wgServer;
	$text="";
	$testtext = "<element style=color:red>hallo</element><br>";
	if( $par == '' ) {
		$from = $wgRequest->getText( 'from' );
		$command = $wgRequest->getText( 'co' );
		$to = $wgRequest->getText( 'to' );
		
	} else {
		$from = $par;
	}
	$dbr = wfGetDB( DB_SLAVE );
	$options = array();
	$where = array( 'cat_title' => $from );
	$value = $dbr->selectField( 'category', 'count(cat_title)', $where, __METHOD__, $options );
	$line;
	$t1;
	$t2;
	$t3;
	$wgOut->addHTML(
		wfMsgExt( 'categoryknowledgerepairpagetext', array( 'parse' ) )
	);
	if ($from != '') {
		
		if ($value>0){
			//removeremoveremoveremvoremoveremoveremoveremoveremvoremoveremoveremoveremoveremvoremoveremoveremoveremoveremvoremove
			$posremove = stripos($command, "remove");
			if (strlen($posremove)!=0) {
				$cat1 = $from;
				$cat2 = $to;
				deleteLinkKR($cat1, $cat2);
				deleteText1KR($cat1, $cat2);
			}
			//removeremoveremoveremvoremoveremoveremoveremoveremvoremoveremoveremoveremoveremvoremoveremoveremoveremoveremvoremove
			//--explanationtableexplanationtableexplanationtableexplanationtableexplanationtableexplanationtableexplanationtable
			$wgOut->addHTML("<h2 >General statistics:</h2 >");
			$wgOut->addHTML("<table width = '95%'border='3'bordercolor='#2F6FFF'>");
			$wgOut->addHTML("<tr><td>Subcategories</td><td>Subcategories are categories, which are a specialization of another category.</td></tr>");
			$wgOut->addHTML("<tr><td>Supercategories</td><td>Supercategories are categories, which are a generalization of other categories.</td></tr>");
			$wgOut->addHTML("<tr><td>Elements</td><td>Elements are individuals of a category, however, there also might be elements which are not type of a certain category.</td></tr>");
			$wgOut->addHTML("<tr><td>Siblings</td><td>Siblings are categories, which have a common supercategory.</td></tr>");
			$wgOut->addHTML("<tr><td>Properties</td><td>The value 'Properties' indicates the number of properties of a category.</td></tr>");
			$wgOut->addHTML("<tr><td>Element properties</td><td>The value 'Element properties' indicates the number of properties of all the elements, which are type of a certain category.</td></tr>");
			$wgOut->addHTML("<tr><td>Redundant links</td><td>This collumn shows how many redundant links a category has. If there is a cylce this value cannot be calculated until the cycle has been resolved.</td></tr>");
			$wgOut->addHTML("<tr><td>Path length to top</td><td>This collumn shows the number of supercategories in a row until reaching the top. If there is a cylce this value cannot be calculated until the cycle has been resolved.</td></tr>");
			$wgOut->addHTML("<tr><td>Path length to bottom</td><td>This collumn shows the number of subcategories in a row until reaching the bottom. If there is a cylce this value cannot be calculated until the cycle has been resolved.</td></tr>");
			$wgOut->addHTML("<tr><td>Subcategories on branch</td><td>This collumn shows the number of subcategories on the branch of the category under consideration starting at that category.</td></tr>");
			$wgOut->addHTML("<tr><td>Elements on branch</td><td>This collumn shows the number of elements on the branch of the category under consideration starting at that category.</td></tr>");
			$wgOut->addHTML("</table><hr>");
			//--explanationtableexplanationtableexplanationtableexplanationtableexplanationtableexplanationtableexplanationtable
			$line = "<hr>";
			$t1 = "General Statistics:";
			$t2 = "Redundant links:";
			$t3 = "Name similarities:";
			$subcats = numberOfSubcategoriesKR($from);
			$minsubcats = minNumberOfSubcategoriesKR();
			$maxsubcats = maxNumberOfSubcategoriesKR();
			$avgsubcats = avgNumberOfSubcategoriesKR();
			$avgsubcats = number_format($avgsubcats,3);
			$pages = numberOfPagesKR($from);
			$minpages = minNumberOfPagesKR();
			$maxpages = maxNumberOfPagesKR();
			$avgpages = avgNumberOfPagesKR();
			$avgpages = number_format($avgpages,3);
			$instances = numberOfInstancesKR($from);
			$mininstances = minNumberOfInstancesKR();
			$maxinstances = maxNumberOfInstancesKR();
			$avginstances = avgNumberOfInstancesKR();
			$supercategories = numberOfSupercategoriesKR($from);
			$minavgmaxnumberofsupercategories = minAvgMaxNumberOfSupercategoriesKR();
			$minavgmaxnumberofsupercategories[1]=number_format($minavgmaxnumberofsupercategories[1],3);
			$properties = numberOfPropertiesKR($from);
			$text8 = unfilledProperties($from);
			$text10 = checkPropertyCardinality($from);
			$minavgmaxpathtotop = array();
			$minavgmaxpathtobottom = array();
			$allchildren = array();
			$text0 = "{$from} has:<br>";
			$text1 = "<b>{$subcats}</b> subcategories, the minimum is <b>{$minsubcats}</b>, the average is <b>{$avgsubcats}</b> and the maximum is <b>{$maxsubcats}</b>";
			$text2 = "<b>{$pages}</b> pages as instances, the minimum is <b>{$minpages}</b>, the average is <b>{$avgpages}</b> and the maximum is <b>{$maxpages}</b>";
			$text3 = "<b>{$instances}</b> instances, the minimum is <b>{$mininstances}</b>, the average is <b>{$avginstances}</b> and the maximum is <b>{$maxinstances}</b>";
			$text4 = "<b>{$supercategories}</b> supercategories, the minimum is <b>{$minavgmaxnumberofsupercategories[0]}</b>, the average is <b>{$minavgmaxnumberofsupercategories[1]}</b> and the maximum is <b>{$minavgmaxnumberofsupercategories[2]}</b>";
			$names = checkNameStartEndEditDistance1KR($from);
			$text6 = "<b>{$properties}</b> filled properties under usage";
			$textdivider="<br>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>";
			$bgcolor1 ='#FFFF33';
			$colok = '#99FF33';
			$coloknok = '#FF9933';
			$colnok = '#FF3300';
			$colsubcategories = '#FFFFFF';
			if ($subcats==$minsubcats||$subcats==$maxsubcats) $colsubcategories = $coloknok;
			$colinstances = 'FFFFFF';
			if ($pages==$minpages||$pages==$maxpages) $colinstances = $coloknok;
			$colsupercategories = '#FFFFFF';
			if ($supercategories==$minavgmaxnumberofsupercategories[0]||$supercategories==$minavgmaxnumberofsupercategories[2]) $colsupercategories = $coloknok;
			$teststring = "[[:Category:Van]]";
			$siblingsanalysis = siblingsAnalysisKR($from);
			$siblingsum=0;
			for ($j=0;$j<count($siblingsanalysis);$j++){
				$k=$j+1;
				$siblingsum+=$siblingsanalysis[$k];
			}
			$colsiblingsum = '#FFFFFF';
			if ($siblingsum==0) $colsiblingsum = $coloknok;
			$properties = numberOfPropertiesKR($from);
			//------------------------------------------------------------------------------------------
			if($pages == 0)$numofpageproperties="No elements!";
			else{
				$instances = getInstancesKR($from);	
				$propertyset = array();
				for ($n=0;$n<count($instances);$n++){//auf Fehler testen!!!!!!!!!!!!!!!
					$propertysetx=getPropertiesKR($instances[$n]);
					
					for ($o = 0; $o<count($propertysetx);$o++){
						if (in_array($propertysetx[$o], $propertyset) ==false) array_push($propertyset, $propertysetx[$o]);
					}
				}
				$numofpageproperties=count($propertyset);
			}
			$colnumofpageproperties = '#FFFFFF';
				if ($numofpageproperties==0) $colnumofpageproperties = $coloknok;
			//------------------------------------------------------------------------------------------
			$minavgmaxpathtotop = array();
			$minavgmaxpathtobottom = array();
			$cycleresult = checkForCycleKR($from);
			$redundantlinks="";
			$colpathtotop="";
			$colpathtobottom="";
			if(count($cycleresult)==0){
				$minavgmaxpathtotop = minAvgMaxPathToTopKR($from);
				$minavgmaxpathtobottom = minAvgMaxPathToBottomKR($from);
				$allchildren = array();
				$allchildren = numberOfAllChildren($from);
				$redLinks = array();
				$redundantLinks = redundantLink1KR($from);
				$countRedundantLinks = count($redundantLinks);
				$colredundantlinks = '#FFFFFF';
				if ($countRedundantLinks!='0') $colredundantlinks = $colnok;
			}
			else {
				$minavgmaxpathtotop[0] = -1;
				$minavgmaxpathtotop[2] = -1;
				$minavgmaxpathtobottom[0] = -1;
				$minavgmaxpathtobottom[2] = -1;
				$allchildren[0] = -1;
				$allchildren[1] = -1;
				$redundantlinks  = -1;
			}
			$wgOut->addHTML("<table width = '95%' border='3'bordercolor='#2F6FFF'>");
			$wgOut->addHTML("<tr align = 'center' valign = 'top'><th>Category name</th><th>Subcategories<br>min=$minsubcats<br>avg=$avgsubcats<br>max=$maxsubcats</th><th>Supercategories<br>min=$minavgmaxnumberofsupercategories[0]<br>avg=$minavgmaxnumberofsupercategories[1]<br>max=$minavgmaxnumberofsupercategories[2]</th><th>Elements<br>min=$minpages<br>avg=$avgpages<br>max=$maxpages</th><th>Siblings</th><th>Properties</th><th>Element properties</th><th>Redundant links</th><th>Path length to top<br>min-max</th><th>Path length to bottom<br>min-max</th><th>Subcategories on branch</th><th>Elements on branch</th></tr>");
			$wgOut->addHTML("<tr align = 'center'>");
			$wgOut->addHTML("<td>");
			$wgOut->addWikiText("[[:Category:$from|$from]]");
			$wgOut->addHTML("</td>");
			$wgOut->addHTML("<td bgcolor=$colsubcategories>$subcats</td>");
			$wgOut->addHTML("<td bgcolor=$colsupercategories>$supercategories</td>");
			$wgOut->addHTML("<td bgcolor=$colinstances>$pages</td>");
			$wgOut->addHTML("<td bgcolor=$colsiblingsum>$siblingsum</td>");
			$wgOut->addHTML("<td>$properties</td>");
			$wgOut->addHTML("<td bgcolor=$colnumofpageproperties>$numofpageproperties</td>");
			$src = wfMsg('icon_cycle');
			if ($redundantlinks==-1) $wgOut->addHTML("<td><img width = '30' height='30' alt = 'Cycle!' src='$src'/></td>");
			else$wgOut->addHTML("<td bgcolor=$colredundantlinks>$countRedundantLinks</td>");
			if ($minavgmaxpathtotop[0]==-1||$minavgmaxpathtotop[2]==-1) $wgOut->addHTML("<td><img width = '30' height='30' alt = 'Cycle!' src='$src'/></td>");
			else$wgOut->addHTML("<td bgcolor=$colpathtotop>$minavgmaxpathtotop[0]-$minavgmaxpathtotop[2]</td>");
			if ($minavgmaxpathtobottom[0]==-1||$minavgmaxpathtobottom[2]==-1) $wgOut->addHTML("<td><img width = '30' height='30' alt = 'Cycle!' src='$src'/></td>");
			else$wgOut->addHTML("<td bgcolor=$colpathtobottom>$minavgmaxpathtobottom[0]-$minavgmaxpathtobottom[2]</td>");
			if ($allchildren[0]==-1) $wgOut->addHTML("<td><img width = '30' height='30' alt = 'Cycle!' src='$src'/></td>");
			else$wgOut->addHTML("<td >$allchildren[0]</td>");
			if ($allchildren[1]==-1) $wgOut->addHTML("<td><img width = '30' height='30' alt = 'Cycle!' src='$src'/></td>");
			else$wgOut->addHTML("<td >$allchildren[1]</td>");
			$wgOut->addHTML("</table>");
			$countnames = count($names[0]);
			if(count($names[0])>0){
				$wgOut->addHTML("<h2 >Name similarities:</h2 >");
				$wgOut->addHTML("This list displays categories with a name similar to the name of the category under consideration. Similar names of categories might be a hint that the categories are representing the same and thus should be merged.");
				$namespace = 14;
				if($namespace==14)$wgOut->addWikiText("[[:Category:$from|$from]]"); 
				else if($namespace==0)$wgOut->addWikiText("[[:$from|$from]]"); 
				else if($namespace==102)$wgOut->addWikiText("[[:Property:$from|$from]]"); 
				else if($namespace==10)$wgOut->addWikiText("[[Template:$from|$from]]"); 
				else if($namespace==108)$wgOut->addWikiText("[[Concept:$from|$from]]"); 
				else $wgOut->addWikiText("$from"); 
				$wgOut->addHTML("<ul>");
				$countsimilarcats=count($names[0]);
				for($j=0;$j<$countsimilarcats;$j++){
					$id = array_pop($names[0]);
					$ed = array_pop($names[1]);
					$where = array('smw_id'=>$id);
					$similarcat = $dbr->selectField( 'smw_ids', 'smw_title', $where, __METHOD__, $options );
					$namespace = $dbr->selectField( 'smw_ids', 'smw_namespace', $where, __METHOD__, $options );
					$wgOut->addHTML("<li>");
					$similarcat = str_replace('_',' ',$similarcat);
					$namespace = 14;
					if($namespace==14)$wgOut->addWikiText("[[:Category:$similarcat|$similarcat]] ([http://en.wikipedia.org/wiki/Edit_distance Edit Distance]: $ed)"); 
					else if($namespace==0)$wgOut->addWikiText("[[:$similarcat|$similarcat]] ([http://en.wikipedia.org/wiki/Edit_distance Edit Distance]: $ed)"); 
					else if($namespace==102)$wgOut->addWikiText("[[:Property:$similarcat|$similarcat]] ([http://en.wikipedia.org/wiki/Edit_distance Edit Distance]: $ed)"); 
					else if($namespace==10)$wgOut->addWikiText("[[Template:$similarcat|$similarcat]] ([http://en.wikipedia.org/wiki/Edit_distance Edit Distance]: $ed)"); 
					else if($namespace==108)$wgOut->addWikiText("[[Concept:$similarcat|$similarcat]] ([http://en.wikipedia.org/wiki/Edit_distance Edit Distance]: $ed)"); 
					else $wgOut->addWikiText("$similarcat ([http://en.wikipedia.org/wiki/Edit_distance Edit Distance]: $ed)"); 
					//andere typen (properties zB) hinzuf�gen
					$wgOut->addHTML("</li>");
				}
				$wgOut->addHTML("</ul>");
				}
			//propsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropset
			$propyset = testPropertySet($from);
			$countresult = count($propyset);
			if ($countresult>0){
				$wgOut->addHTML("<h2 >Categories with similar property sets:</h2 >");
				$wgOut->addHTML("This list displays categories with similar propertysets. If there are at least 50% similar properties, the corresponding categories are listed. The common properties are diplayed in brackets. The equality of a set of properties might be a hint that the categories under consideration are similar and thus be merged.");
				$wgOut->addWikiText("[[:Category:$from|$from]]");
				$wgOut->addHTML("<ul>");
				for ($i=0;$i<$countresult;$i++){
					$id = $propyset[$i];
					$properties = $propyset[$i+1];
					$countproperties = count($properties);
					$where = array('smw_id' => $id);
					$cat = $dbr->selectField( 'smw_ids', 'smw_sortkey', $where, __METHOD__, $options );
					$wgOut->addHTML("<li>");
					$outstring = "[[:Category:$cat|$cat]] (";
					for ($k=0;$k<$countproperties;$k++){
						$id = array_pop($properties);
						$where = array('smw_id' => $id);
						$property = $dbr->selectField( 'smw_ids', 'smw_sortkey', $where, __METHOD__, $options );
						if ($k!=$countproperties-1) $outstring.="[[:Property:$property|$property]], ";
						else $outstring.="[[:Property:$property|$property]])";
					}
					$wgOut->addWikiText($outstring); 
					$wgOut->addHTML("</li>");
					$i++;
				}
				$wgOut->addHTML("</ul>");
			}
			//propsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropsetpropset
			//cyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecycle
			if(count($cycleresult)>0){
				$wgOut->addHTML("<h2 >Cycle:</h2 >");
				$wgOut->addHTML("The category under consideration ist part of a cycle or is a subcategory of another category which is part of a cycle. Due to consistency and functionality, cycles must be avoided.");
				outputCycleKR($cycleresult);
				$wgOut->addHTML("");
			}
			//cyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecyclecycle
			if((count($cycleresult)==0)&&($countRedundantLinks>0)){	
				$wgOut->addHTML("<h2 >Redundant and non redundant subcategory-of relations:</h2>");
				$wgOut->addHTML("<p>This list displays all the redundant and non redundant subcategory-off relations of the category under consideration. Redundant means that this category is a subcategory of two or more other categories which are on the same branch in the category tree. After clicking on 'Remove Redundancy' the corresponding link will be deleted.</p>");
				$link = $wgServer;
				$link.="/index.php/Special:CategoryKnowledgeRepair?from=";
				//$link = "../index.php?title=Special%3ACategoryKnowledgeRepair&from=";
				//redundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinks
				$dbr = wfGetDB( DB_SLAVE );
				for ($i=0;$i<$countRedundantLinks;$i++){
						$id = array_pop($redundantLinks);
						$where = array('smw_id' => $id);
						$cat = $dbr->selectField( 'smw_ids', 'smw_sortkey', $where, __METHOD__, $options );
						$redLinks[$i] = $cat;
				}
				$paths = getSubPathsKR($from);
				sort($paths);
				$wgOut->addHTML("<ol>");
				for ($i=0;$i<count($paths);$i++){
					$wgOut->addHTML("<li>");
					$outstring = "";
					for($j=0;$j<count($paths[$i]);$j++){
						$cat = $paths[$i][$j];
						$outstring.= "[[:Category:$cat|$cat]]";
						if ($j<count($paths[$i])-1)$outstring.= "->";				
					}
					$wgOut->addWikiText($outstring);
					$wgOut->addHTML("</li>");
					if (in_array($paths[$i][1],$redLinks)==true){
					$specificlink=$link;
					$specificlink.=$from;
					$specificlink.="&co=remove&to=";
					$cat = $paths[$i][1];
					$specificlink.="$cat";
					$wgOut->addHTML("<a href = $specificlink>Remove Redundancy</a>");
					}
					$wgOut->addHTML("<hr>");
				}
				$wgOut->addHTML("</ol>");
			}
				//redundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinksredundantLinks
		}	
		else {
			$wgOut->addHTML("This category does not exist");
		}
		
	}
}
function numberOfSubcategoriesKR($categoryname){

	$options = array();
	
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cat_title' => $categoryname );
	$value = $dbr->selectField( 'category', 'cat_subcats', $where, __METHOD__, $options );
	return $value;
}
function minNumberOfSubcategoriesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'min(cat_subcats)', $where, __METHOD__, $options );
	return $value;
}
function maxNumberOfSubcategoriesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'max(cat_subcats)', $where, __METHOD__, $options );
	return $value;
}
function avgNumberOfSubcategoriesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'avg(cat_subcats)', $where, __METHOD__, $options );
	return $value;
}	
function numberOfPagesKR($categoryname){
	$value1 = numberOfInstancesKR($categoryname);
	$value2 = numberOfSubcategoriesKR($categoryname);
	return $value1-$value2;
}
function minNumberOfPagesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'min(cat_pages-cat_subcats)', $where, __METHOD__, $options );
	return $value;
}
function maxNumberOfPagesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'max(cat_pages-cat_subcats)', $where, __METHOD__, $options );
	return $value;
}
function avgNumberOfPagesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'avg(cat_pages-cat_subcats)', $where, __METHOD__, $options );
	return $value;
}
function numberOfInstancesKR($categoryname){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cat_title' => $categoryname );
	$value = $dbr->selectField( 'category', 'cat_pages', $where, __METHOD__, $options );
	return $value;
}
function minNumberOfInstancesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'min(cat_pages)', $where, __METHOD__, $options );
	return $value;
}
function maxNumberOfInstancesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'max(cat_pages)', $where, __METHOD__, $options );
	return $value;
}
function avgNumberOfInstancesKR(){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$value = $dbr->selectField( 'category', 'avg(cat_pages)', $where, __METHOD__, $options );
	return $value;
}
function numberOfSupercategoriesKR($categoryname){
	$options = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cl_sortkey' => $categoryname );
	$value = $dbr->selectField( 'categorylinks', 'count(cl_to)', $where, __METHOD__, $options );
	return $value;
}
function minAvgMaxNumberOfSupercategoriesKR(){
	$options = array();
	$where = array();
	$myarray = array();
	$dbr = wfGetDB( DB_SLAVE );
	$value = $dbr->selectField( 'category', 'count(*)', $where, __METHOD__, $options );
	$temp1= $dbr->select( 'category', 'cat_title', $where, $myarray, $myarray );
	$cats = array();
	$min = 10000;
	$max = 0;
	$avg = 0;
	$sum = 0;
	for ($i=0;$i<$value;$i++){
		$tempx= $temp1->fetchRow();
		$cats[$i]=$tempx['cat_title'];
		$val = numberOfSupercategoriesKR($cats[$i]);
		$sum = $sum+$val;
		if ($val < $min) $min = $val;
		if ($val > $max) $max = $val;
	}
	$avg = $sum/$value;
	$results = array();
	$results[0] = $min;
	$results[1] = $avg;
	$results[2] = $max;
	return $results;
}
function siblingsAnalysisKR($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$result = array();
	$num_of_supercats = numberOfSupercategoriesKR($categoryname);
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cl_sortkey' => $categoryname );
	$temp1= $dbr->select( 'categorylinks', 'cl_to', $where, $myarray, $myarray );
	$i=0;
	for ($j=0;$j<$num_of_supercats;$j++){
		$tempx= $temp1->fetchRow();
		$supercats[$j]=$tempx['cl_to'];
		$result[$i] = $supercats[$j];
		$i++;
		$result[$i] = numberOfSubcategoriesKR($supercats[$j])-1;
		$i++;
		$result[$i] = numberOfInstancesKR($supercats[$j])-$result[$i-1]-1;
		$i++;
		
	}
	return $result;
}
function numberOfPropertiesKR($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$categoryname = str_replace(' ','_',$categoryname);
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'smw_title' => $categoryname );
	$id = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
	$where = array( 's_id' => $id );
	$value = $dbr->selectField( 'smw_atts2', 'count(*)', $where, __METHOD__, $options );
	return $value;
}
//--------------------------------------------------------------------------------------------
function numberOfAllChildren($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$result = array();
	$ids_of_cats = array();
	$subcats = array();
	$result[0]=0;
	$result[1]=0;
	$tempresult = array();
	$num_of_subcats = numberOfSubcategoriesKR($categoryname);
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cl_to' => $categoryname);
	$number_of_links = $dbr->selectField( 'categorylinks', 'count(*)', $where, __METHOD__, $options );
	$where = array( 'cl_to' => $categoryname  );
	$temp1= $dbr->select( 'categorylinks', 'cl_sortkey', $where, $myarray, $myarray );
	for ($k=0;$k<$number_of_links;$k++){
		$tempx= $temp1->fetchRow();
		$tempy=$tempx['cl_sortkey'];
		$tempy = str_replace(' ','_',$tempy);
		$where = array( 'page_title' => $tempy,  );
		$namespace = $dbr->selectField( 'page', 'page_namespace', $where, __METHOD__, $options );
		$tempy = str_replace('_',' ',$tempy);
		if ($namespace == 14) array_push($subcats,$tempy);	
	}
	$result[0] = $result[0] + numberOfSubcategoriesKR($categoryname);
		$result[1] = $result[1] + numberOfPagesKR($categoryname);
	for ($j=0;$j<$num_of_subcats;$j++){
		$tempresult=numberOfAllChildren($subcats[$j]);
		$result[0] = $result[0] + $tempresult[0];
		$result[1] = $result[1] + $tempresult[1];
	}
	return $result;
}
function unfilledProperties($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$text="";
	$counter = 0;
	$instances = array();
	$properties = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cl_to' => $categoryname );
	$count = $dbr->selectField( 'categorylinks', 'count(*)', $where, __METHOD__, $options );
	$temp1= $dbr->select( 'categorylinks', 'cl_sortkey', $where, $myarray, $myarray );
	
	for ($j=0;$j<$count;$j++){
		$tempx= $temp1->fetchRow();
		$instances[$j]=$tempx['cl_sortkey'];
		$instances[$j] = str_replace(' ','_',$instances[$j]);
		$where = array( 'page_title' => $instances[$j] );
		$id = $dbr->selectField( 'page', 'page_id', $where, __METHOD__, $options );
		$where = array( 'smw_title' => $instances[$j] );
		$instancesmwid = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
		$where = array( 'pl_from' => $id );
		$count2 = $dbr->selectField( 'pagelinks', 'count(*)', $where, __METHOD__, $options );
		$temp2= $dbr->select( 'pagelinks', 'pl_title', $where, $myarray, $myarray );
		
		for ($i=0;$i<$count2;$i++){
			$tempx= $temp2->fetchRow();
			$properties[$i]=$tempx['pl_title'];
			$where = array( 'smw_title' => $properties[$i] );
			$propertyid = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
			$where = array( 's_id' => $instancesmwid, 'p_id'=>$propertyid );
			$count3 = $dbr->selectField( 'smw_atts2', 'count(*)', $where, __METHOD__, $options );
			if ($count3 ==0) {
				
					$text = "{$text}{$properties[$i]} of {$instances[$j]}";
					$counter++;
					if ($i != $count2-1) $text = "{$text}<br>";
				
				
			}
		}
	}
	if ($text == "") $text = "";
	return $text;
}
function getInstancesKR($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$instances = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cl_to' => $categoryname );
	$temp1= $dbr->select( 'categorylinks', 'cl_sortkey', $where, $myarray, $myarray );
	$count= $dbr->selectField( 'categorylinks', 'count(*)', $where, $myarray, $myarray );
	for ($m=0;$m<$count;$m++){
		$tempx= $temp1->fetchRow();
		$tempy=$tempx['cl_sortkey'];
		$tempy = str_replace(' ','_',$tempy);
		$where = array( 'page_title' => $tempy  );
		$namespace = $dbr->selectField( 'page', 'page_namespace', $where, __METHOD__, $options );
		if ($namespace == 0) array_push($instances,$tempy);
	}		
	return $instances;		
}
function getPropertiesKR($instance){
	$options = array();
	$where = array();
	$myarray = array();
	$properties = array();
	$instance = str_replace(' ','_',$instance);
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'page_title' => $instance );
	$id= $dbr->selectField( 'page', 'page_id', $where, $myarray, $myarray );
	$where = array( 'pl_from' => $id,'pl_namespace'=>102 );
	$temp1= $dbr->select( 'pagelinks', 'pl_title', $where, $myarray, $myarray );
	$count= $dbr->selectField( 'pagelinks', 'count(*)', $where, $myarray, $myarray );
	for ($j=0;$j<$count;$j++){
		$tempx= $temp1->fetchRow();
		$properties[$j]=$tempx['pl_title'];
	}
	return $properties;
}
function getPropertiesForPropertySet($instance){
	$options = array();
	$where = array();
	$myarray = array();
	$properties = array();
	$instance = str_replace(' ','_',$instance);
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'smw_title' => $instance );
	$id= $dbr->selectField( 'smw_ids', 'smw_id', $where, $myarray, $myarray );
	$where = array( 's_id' => $id );
	$temp1= $dbr->select( 'smw_atts2', 'p_id', $where, $myarray, $myarray );
	$count= $dbr->selectField( 'smw_atts2', 'count(*)', $where, $myarray, $myarray );
	for ($j=0;$j<$count;$j++){
		$tempx= $temp1->fetchRow();
		$properties[$j]=$tempx['p_id'];
	}
	return $properties;
}
function testPropertySet($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$text = "";
	$dbr = wfGetDB( DB_SLAVE );
	$helpset = array();
	$propertysettemp = array();
	$instances=array();
	$instancestemp = array();
	if(count($instances) == 0) return $results = array();
	$propertyset = array();
	for ($n=0;$n<count($instances);$n++){//auf Fehler testen!!!!!!!!!!!!!!!
		$propertysetx=getPropertiesForPropertySet($instances[$n]);
		for ($o = 0; $o<count($propertysetx);$o++){
			if (in_array($propertysetx[$o], $propertyset) ==false) array_push($propertyset, $propertysetx[$o]);
		}
	}
	$result = array();
	$results = array();
	$siblingcats = array();
	$num_of_supercats = numberOfSupercategoriesKR($categoryname);
	$where = array( 'cl_sortkey' => $categoryname );
	$temp1= $dbr->select( 'categorylinks', 'cl_to', $where, $myarray, $myarray );
	for ($j=0;$j<$num_of_supercats;$j++){
		$tempx= $temp1->fetchRow();
		$supercats[$j]=$tempx['cl_to'];
	}
	for ($i=0;$i<$num_of_supercats;$i++){
		$num_of_links = numberOfInstancesKR($supercats[$i]);//update an michael
		$where = array( 'cl_to' => $supercats[$i] );
		$temp1= $dbr->select( 'categorylinks', 'cl_sortkey', $where, $myarray, $myarray );
		
		for ($j=0;$j<$num_of_links;$j++){//update an michael
			$tempx= $temp1->fetchRow();
			$tempy=$tempx['cl_sortkey'];
			$tempy = str_replace(' ','_',$tempy);
			$where = array( 'page_title' => $tempy  );
			$namespace = $dbr->selectField( 'page', 'page_namespace', $where, __METHOD__, $options );
			$tempy = str_replace('_',' ',$tempy);
			if ($namespace == 14&&$tempy!=$categoryname){
				array_push($siblingcats,$tempy);
				 // in case of having an instance and not a category because of the fact that numberOfSubcategoriesKR() does not count instances
			}
		}
	}
	for ($l=0;$l<count($siblingcats);$l++){
		$where = array( 'smw_title'=>$siblingcats[$l]);
		$id = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
		$counter = 0;
		$tempresult = array();
		$instancestemp = getInstancesKR($siblingcats[$l]);
		if (count($instancestemp)>0){
			for ($n=0;$n<count($instancestemp);$n++){//auf Fehler testen!!!!!!!!!!!!!!!
				$propertysetx=getPropertiesForPropertySet($instancestemp[$n]);
				if($n==0)$propertysettemp = $propertysetx;
				else $propertysettemp = array_merge($propertysettemp,$propertysetx);
			}
			$propertysettemp=array_unique($propertysettemp);
			if (count($propertyset)<count($propertysettemp)){
				for ($o = 0; $o<count($propertyset);$o++){
					if (in_array($propertyset[$o], $propertysettemp) ==true) {
						$counter++;
						array_push($tempresult, $propertyset[$o]);
					}
				}
				if ($counter >= count($propertysettemp)/2&&$counter>0) {
					array_push($results,$id);
					array_push($results, $tempresult);
				}
			}
			else{
				for ($o = 0; $o<count($propertysettemp);$o++){
					if (in_array($propertysettemp[$o], $propertyset) ==true){
						$counter++;
						array_push($tempresult, $propertysettemp[$o]);
					}
				}
				if ($counter >= count($propertyset)/2&&$counter>0) {
					array_push($results,$id);
					array_push($results, $tempresult);
				}
			}
		}
	}
	return $results;
}
function checkPropertyCardinality($categoryname){//achtung wenn property links nicht in der tabelle smw_atts2 erscheinen (aus welchen gr�nden auch immer?!)
	$options = array();
	$where = array();
	$myarray = array();
	$text = "";
	$dbr = wfGetDB( DB_SLAVE );
    $instances = array();
	$tempproperties = array();
	$atts = array();
	$instances = getInstancesKR($categoryname);
	for ($i=0;$i<count($instances);$i++){
		$tempproperties = getPropertiesKR($instances[$i]);
		$where = array( 'smw_title' => $instances[$i] );
		$instancesmwid= $dbr->selectField( 'smw_ids', 'smw_id', $where, $myarray, $myarray );
		for ($j=0;$j<count($tempproperties);$j++){
			$tempproperties[$j] = str_replace(' ','_',$tempproperties[$j]);
			$where = array( 'smw_title' => $tempproperties[$j] );
			$smwid= $dbr->selectField( 'smw_ids', 'smw_id', $where, $myarray, $myarray );
			$where = array( 's_id' => $smwid );
			$temp1= $dbr->select( 'smw_atts2', 'p_id', $where, $myarray, $myarray );
			$count= $dbr->selectField( 'smw_atts2', 'count(*)', $where, $myarray, $myarray );
			if ($count>0){
				for ($k=0;$k<$count;$k++){
					$value = -1;
					$count3 = -2;
					$tempx= $temp1->fetchRow();
					$atts[$k]=$tempx['p_id'];
					$where = array( 'smw_id' => $atts[$k] );
					$name = $dbr->selectField( 'smw_ids', 'smw_title', $where, $myarray, $myarray );
					if ($name=="Cardinality"){
						$where = array(  's_id' => $smwid,'p_id'=> $atts[$j]  );
						$value = $dbr->selectField( 'smw_atts2', 'value_xsd', $where, $myarray, $myarray );
						$where = array( 's_id' => $instancesmwid,'p_id'=>$smwid );
						$count3 = $dbr->selectField( 'smw_atts2', 'count(*)', $where, $myarray, $myarray );
						//if($value==$count3&&$count3>0)$text = "{$text} Cardinality of {$tempproperties[$j]} should be {$value} and is correct";
						if($value==$count3&&$count3>0)$text = "{$text}";
						
						elseif ($count3>0){
							$text = "{$text} Cardinality of {$tempproperties[$j]} should be {$value} but it is {$count3}";
							if($j!=count($tempproperties)-1) $text = "{$text}<br>";
						}
					}
				}
			}
		}
	}
	if ($text == "") $text = "";
	return $text;
}
function getSuperCategoriesKR($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$supercategories = array();
	$dbr = wfGetDB( DB_SLAVE );
	$title = str_replace(' ','_',$categoryname);
	$where = array( 'page_title' => $title, 'page_namespace'=>14 );
	$id= $dbr->selectField( 'page', 'page_id', $where, $myarray, $myarray );
	$where = array( 'cl_from' => $id );
	$temp1= $dbr->select( 'categorylinks', 'cl_to', $where, $myarray, $myarray );
	$count= $dbr->selectField( 'categorylinks', 'count(*)', $where, $myarray, $myarray );
	for ($m=0;$m<$count;$m++){
		$tempx= $temp1->fetchRow();
		$supercategories[$m]=$tempx['cl_to'];
	}		
	return $supercategories;		
}		
function minAvgMaxPathToTopKR($categoryname){
	
	$paths = array();//[0] = min, [1]=avg,[2]=max
	$result = array();
	$min = 10000;
	$max = -1;
	//$avg = 0;
	$result[0]=0;
	$result[1]=0;
	$result[2]=0;
	$tempresult = array();
	$supercategories = getSuperCategoriesKR($categoryname);
	if (count($supercategories)>0){
		$result[0] = 1;
		//$result[1] = 1;
		$result[2] = 1;
	}
	if (count($supercategories)==1){
		$tempresult = minAvgMaxPathToTopKR($supercategories[0]);
		$result[0]=$result[0]+$tempresult[0];
		//$result[1]=$result[1]+$tempresult[1];
		$result[2]=$result[2]+$tempresult[2];
	}
	if (count($supercategories)>1){
		for($i=0;$i<count($supercategories);$i++){
			$tempresult = minAvgMaxPathToTopKR($supercategories[$i]);
			if ($tempresult[0]<$min) $min = $tempresult[0];
			if ($tempresult[2]>$max) $max = $tempresult[2];
			//$avg = $avg + $tempresult[1];
		}
		$result[0]=$result[0]+$min;
		//$result[1]=$result[1]+$avg;
		$result[2]=$result[2]+$max;
	}
	return $result;
}
function getSubCategoriesKR($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$subcategories = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cl_to' => $categoryname );
	$temp1= $dbr->select( 'categorylinks', 'cl_from', $where, $myarray, $myarray );
	$count= $dbr->selectField( 'categorylinks', 'count(*)', $where, $myarray, $myarray );
	for ($m=0;$m<$count;$m++){
		$tempx= $temp1->fetchRow();
		$id=$tempx['cl_from'];
		$where = array( 'page_namespace'=>14, 'page_id' => $id  );
		$title = $dbr->selectField( 'page', 'page_title', $where, __METHOD__, $options );
		if ($title ) array_push($subcategories,$title);
	}		
	return $subcategories;		
}	
function minAvgMaxPathToBottomKR($categoryname){
	$paths = array();//[0] = min, [1]=avg,[2]=max
	$result = array();
	$min = 10000;
	$max = -1;
	//$avg = 0;
	$result[0]=0;
	$result[1]=0;
	$result[2]=0;
	$tempresult = array();
	$subcategories = getSubCategoriesKR($categoryname);
	
	if (count($subcategories)>0){
		$result[0] = 1;
		//$result[1] = 1;
		$result[2] = 1;
	}
	if (count($subcategories)==1){
		$tempresult = minAvgMaxPathToBottomKR($subcategories[0]);
		$result[0]=$result[0]+$tempresult[0];
		//$result[1]=$result[1]+$tempresult[1];
		$result[2]=$result[2]+$tempresult[2];
	}
	if (count($subcategories)>1){
		for($i=0;$i<count($subcategories);$i++){
			$tempresult = minAvgMaxPathToBottomKR($subcategories[$i]);
			if ($tempresult[0]<$min) $min = $tempresult[0];
			if ($tempresult[2]>$max) $max = $tempresult[2];
			//$avg = $avg + $tempresult[1];
		}
		$result[0]=$result[0]+$min;
		//$result[1]=$result[1]+$avg;
		$result[2]=$result[2]+$max;
	}
	return $result;
}
function getLinks1KR($name){
	$options = array();
	$where = array();
	$myarray = array();
	$links = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'cl_sortkey' => $name );
	$temp1= $dbr->select( 'categorylinks', 'cl_to', $where, $myarray, $myarray );
	$count = $dbr->selectField( 'categorylinks', 'count(*)', $where, __METHOD__, $options );
	for ($j=0;$j<$count;$j++){
		$tempx= $temp1->fetchRow();
		$tempy=$tempx['cl_to'];
		if ($tempy!=$name)array_push($links,$tempy);
	}
	return $links;
}
function redundantLink1KR($name){
	$options = array();
	$where = array();
	$myarray = array();
	$text = "";
	$dbr = wfGetDB( DB_SLAVE );
	$ids = array();
	$links = array();
	$links = getLinks1KR($name);
	$allLinks = array();
	$templinks = array();
	for ($i=0;$i<count($links);$i++){
		$templinks=getAllLinks1KR($links[$i]);
		$allLinks = array_merge($allLinks, $templinks);
	}
	if (count($links)==0) $text = "{$name} has no links";
	else{
		if(count($allLinks) <count($links)){
			for($i=0;$i<count($allLinks);$i++){
				if (in_array($allLinks[$i],$links)==true){
					$categoryname = str_replace(' ','_',$allLinks[$i]);
					$where = array( 'smw_title'=>$categoryname,'smw_namespace'=>14);
					$id = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
					array_push($ids,$id);
				}
			}
		}
		else{
			for($i=0;$i<count($links);$i++){
				if (in_array($links[$i],$allLinks)==true){
					$categoryname = str_replace(' ','_',$links[$i]);
					$where = array( 'smw_title'=>$categoryname,'smw_namespace'=>14);
					$id = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
					array_push($ids,$id);
				}
			}
		}
	}
	return $ids;//contains the ids of the redundant categorylinks
}
function getAllLinks1KR($name){
	$links = array();
	$links = getLinks1KR($name);
	$allLinks = array();
	$allLinks = getLinks1KR($name);
	$templinks = array();
	for ($i=0;$i<count($links);$i++){
		$templinks=getAllLinks1KR($links[$i]);
		$allLinks = array_merge($allLinks, $templinks);
	}
	return $allLinks;
}
function getSubPathsKR($categoryname){
	$subPath = array();
	$subPaths = array();
	$supercategories = getSuperCategoriesKR($categoryname);
	if (count($supercategories)==0){
		$subPath[0]=$categoryname;
		$subPaths[0] = $subPath;
	}
	else if (count($supercategories)==1){
		$tempSubPaths = array();
		$tempSubPaths = getSubPathsKR($supercategories[0]);
		$count = count($tempSubPaths);
		for ($i=0;$i<$count;$i++){
			$subPaths[$i]=array($categoryname);
			
			for ($k=0;$k<count($tempSubPaths[$i]);$k++){
				array_push($subPaths[$i],$tempSubPaths[$i][$k]);
			}
		}
		
	}
	else if (count($supercategories)>1){
		for ($j=0;$j<count($supercategories);$j++){
			$tempSubPaths = array();
			$tempSubPaths = getSubPathsKR($supercategories[$j]);
			$count = count($tempSubPaths);
			for ($i=0;$i<$count;$i++){
				$subPaths[$j]=array($categoryname);
			
				for ($k=0;$k<count($tempSubPaths[$i]);$k++){
					array_push($subPaths[$j],$tempSubPaths[$i][$k]);
				}
		}
		}
	}
	return $subPaths;
}
function deleteLinkKR($from, $to){//---------------------aufpassen beim deleten auf cl from!!!!!!!!!!!!!!!!
	$options = array();
	$where = array();
	$myarray = array();
	$dbr = wfGetDB( DB_SLAVE );
	$title = str_replace(' ','_',$from);
	$where = array( 'page_title' => $title, 'page_namespace'=>14 );
	$id= $dbr->selectField( 'page', 'page_id', $where, $myarray, $myarray );
	$dbr2 = wfGetDB( DB_MASTER );
	$fname = 'Database::delete';
	$where = array( 'cl_from' => $id, 'cl_to'=>$to );
	$dbr2->delete('categorylinks',$where, $fname);
}
function deleteText1KR($from, $to){//achtung verschieden sprachen
	$options = array();
	$where = array();
	$myarray = array();
	//$to = "Pet";
	$dbr = wfGetDB( DB_SLAVE );
	$title = str_replace(' ','_',$from);
	$where = array( 'page_title' => $title, 'page_namespace'=>14 );
	$textid= $dbr->selectField( 'page', 'page_latest', $where, $myarray, $myarray );
	
	$where = array( 'old_id' => $textid );
	$text= $dbr->selectField( 'text', 'old_text', $where, $myarray, $myarray );
	$temptext = $text;
	$open = "[[";
	$close = "]]";
	while (strlen(stripos($temptext,$open))>0){
		$pos1 = stripos($temptext, $open);
		$pos2 = stripos($temptext, $close);
		$test = substr($temptext,$pos1, $pos2-$pos1+2);
		
		if(stripos($test, "Category")>0&&stripos($test,":")>0&&stripos($test, $to)>0){
			$text = str_replace($test,'',$text);
			$temptext = str_replace($test,'',$temptext);
		}
		else $temptext = substr($temptext, $pos2+2);
		
	}
	$dbr2 = wfGetDB( DB_MASTER );
	$temp=array('old_text'=>$text);
	$where = array( 'old_id' => $textid );
	$fname = 'Database::update';
	$dbr2->update('text',$temp, $where, $fname,$options);

}
function checkNameStartEndEditDistance1KR($categoryname){//ready for Michael
	$options = array();
	$where = array();
	$myarray = array();
	$results = array();
	
	if (strlen($categoryname) == 0)return $results;
	$similarobjects = array();
	$ids = array();
	$editdistances = array();
	$text = "{$categoryname}'s name consists of another entity's name or is part of another entity's name:";
	$temparray = array();
	$temp = "";
	$counter=0;
	$dbr = wfGetDB( DB_SLAVE );
	$where = array( 'page_title' => $categoryname );
	$namespace = $dbr->selectField( 'page', 'page_namespace', $where, __METHOD__, $options );
	$namespace = 14;
	$where = array( 'page_namespace'=>$namespace, "page_title LIKE '{$categoryname[0]}%'");
	
	$count = $dbr->selectField( 'page', 'count(page_title)', $where, __METHOD__, $options );
	$temp1= $dbr->select( 'page', 'page_title', $where, $myarray, $myarray );
	$val = strlen($categoryname);
	$where = array( 'page_namespace'=>$namespace, "page_title LIKE '%{$categoryname[$val-1]}'");
	$count2 = $dbr->selectField( 'page', 'count(page_title)', $where, __METHOD__, $options );
	$temp2= $dbr->select( 'page', 'page_title', $where, $myarray, $myarray );
	$categoryname = strtolower($categoryname);
	$categoryname = str_replace('_',' ',$categoryname);
		for ($j=0;$j<$count;$j++){
			$tempx= $temp1->fetchRow();
			$temparray[$j]=$tempx['page_title'];
			$where = array( 'smw_title'=>$temparray[$j]);
			$id = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
			$temparray[$j] = strtolower($temparray[$j]);
			$temparray[$j] = str_replace('_',' ',$temparray[$j]);
			if(strlen($categoryname)>strlen($temparray[$j])){
				if(strstr($categoryname, $temparray[$j])!=false){
					array_push($similarobjects,$temparray[$j]);
					array_push($ids,$id);
				}
			}
			else if (strstr($temparray[$j], $categoryname)!=false){
				array_push($similarobjects,$temparray[$j]);
				array_push($ids,$id);
			}
		}
		for ($j=0;$j<$count2;$j++){
			$tempx= $temp2->fetchRow();
			$temparray2[$j]=$tempx['page_title'];
			$where = array( 'smw_title'=>$temparray2[$j]);
			$id = $dbr->selectField( 'smw_ids', 'smw_id', $where, __METHOD__, $options );
			$temparray2[$j] = strtolower($temparray2[$j]);
			$temparray2[$j] = str_replace('_',' ',$temparray2[$j]);
			if(strlen($categoryname)>strlen($temparray2[$j])){
				if(strstr($categoryname, $temparray2[$j])!=false){
					array_push($similarobjects,$temparray2[$j]);
					array_push($ids,$id);
				}
			}
			else if (strstr($temparray2[$j], $categoryname)!=false){
				array_push($similarobjects,$temparray2[$j]);
				array_push($ids,$id);
			}
		}
		for($i=0;$i<count($similarobjects);$i++){
			array_push($editdistances, levenshtein($categoryname, $similarobjects[$i]));
		}
		
		if (count($ids)>0 && count($editdistances)>0){
			$helparray=array_combine($ids,$editdistances);
			arsort($helparray);
			$keys = array_keys($helparray);
			array_pop($keys);
			array_pop($helparray);
			$results[0] = $keys;//ids of entities (category or page) 0 = big difference, n = little difference
			$results[1] = $helparray;//edit distances 0 = biggest, n = lowest
		}
		return $results;
}
function outputCycleKR($result){
	global $wgOut, $wgRequest;
	
	$outstring = "[[:Category:$result[0]|$result[0]]] (";
	for ($j=0;$j<count($result);$j++){
		if ($j!=count($result)-1)$outstring .= "[[:Category:$result[$j]|$result[$j]]]-";
		else $outstring .= "[[:Category:$result[$j]|$result[$j])]]";
	}
	$wgOut->addWikiText($outstring); 
}
function checkForCycleKR($categoryname){
	$options = array();
	$where = array();
	$myarray = array();
	$result = array();
	$text = "There is no cycle containing {$categoryname}.";
	$dbr = wfGetDB( DB_SLAVE );
	$options = array();
	$tempx;	
	$temp1;
	$temp2;
	$counter = 0;
	$temparray = array();
	$allready_seen = array();
	$allready_checked = array();
	$pos = $categoryname;
	$help = str_replace( ' ', '_', $categoryname );
	$where = array( 'page_title' => $help,'page_namespace'=>14 );//achtung page vs category
	$posid = $dbr->selectField( 'page', 'page_id', $where, __METHOD__, $options );
	while ($pos!='0'){
		$counter++;
		for($i=0;$i<count($allready_seen);$i++){
			if($pos==$allready_seen[$i]){
				$text = "{$categoryname} is part of a cycle or is a subcategory of a cycle member: ";
				for($k=0;$k<count($allready_seen);$k++) $text = "{$text}{$allready_seen[$k]}---"; 
				$result = $allready_seen;
				$text = "{$text}{$categoryname}";
				$pos = '0';
				$i = count($allready_seen);
			}
		}	
		if($pos == '0') break;
		array_push($allready_seen, $pos);
		$where = array( 'cl_from' => $posid );//achtung page vs category
		$count = $dbr->selectField( 'categorylinks', 'count(*)', $where, __METHOD__, $options );
		$temp1= $dbr->select( 'categorylinks', 'cl_to', $where, $myarray, $myarray );
		$temparray = array();
		for ($j=0;$j<$count;$j++){
			$tempx= $temp1->fetchRow();
			$tempy=$tempx['cl_to'];
			array_push($temparray,$tempy);
		}
		if(array_key_exists(0, $temparray))$pos = $temparray[0];//prevent undefined offset
		$where = array( 'cl_sortkey' => $pos );//achtung page vs category
		$count = $dbr->selectField( 'categorylinks', 'count(*)', $where, __METHOD__, $options );
		$temp1= $dbr->select( 'categorylinks', 'cl_from', $where, $myarray, $myarray );
		for ($j=0;$j<$count;$j++){
			$tempx= $temp1->fetchRow();
			$tempy=$tempx['cl_from'];
			$where = array( 'page_id' => $tempy );
			$tempynamespace = $dbr->selectField( 'page', 'page_namespace', $where, __METHOD__, $options );
			if ($tempynamespace==14){
				$posid = $tempy;
				break;
			}
		}
		if($count>1){
			for ($k=1;$k<count($temparray);$k++){
				
				if (in_array($temparray[$k],$allready_checked)==false) {
					$text = "{$text} !!!!next cycle: {checkForCycleKR($temparray[$k])}";
					checkForCycleKR($temparray[$k]);
					array_push($allready_checked,$temparray[$k]);
				}
				else $text = "{$text} ????not checked: {checkForCycleKR($temparray[$k])}";
			}
		}
		if($count == 0) break;
	}		
	return $result;
}
