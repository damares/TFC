<?php
/**
 * @file
 * @ingroup SpecialPage
 * @author Stephan W�lger
 */


class CategoriesWithSimilarPropertysets extends SpecialPage {

	function CategoriesWithSimilarPropertysets() {
                SpecialPage::SpecialPage('CategoriesWithSimilarPropertysets');
                wfLoadExtensionMessages('OntologyEditor');
        }

	function execute( $par=null )
	{
		wfSpecialCategoriesWithSimilarPropertysets($par);
	}


}

function wfSpecialCategoriesWithSimilarPropertysets( $par=null ) {
	global $wgOut, $wgRequest;

	if( $par == '' ) {
		$from = $wgRequest->getText( 'from' );
		$mydropdown = $wgRequest->getText( 'mydropdown' );
	} else {
		$from = $par;
	}
	$pagenum=(int)$mydropdown;
	$wgOut->addHTML(
	wfMsgExt( 'categorieswithsimilarpropertysetspagetext', array( 'parse' ) ) 
	);
	getSimilarCategoriesS($pagenum);
}
function getSimilarCatsS($categorypageid, $vocab){
	$testcatprops=getPropsForCat($categorypageid);
	$vocabcats = getVocabCatsS($categorypageid, $vocab);	
	$result=array();
	for($i=0;$i<count($vocabcats);$i++){
		$equalprops=array();
		$catxyprops=getPropsForCatS($vocabcats[$i]);
		if(count($testcatprops)>count($catxyprops)){
			for($j=0;$j<count($catxyprops);$j++){
				if(in_array($catxyprops[$j], $testcatprops)==true)array_push($equalprops, $catxyprops[$j]);
			}
		}
		else{
			for($j=0;$j<count($testcatprops);$j++){
				if(in_array($testcatprops[$j], $catxyprops)==true)array_push($equalprops, $testcatprops[$j]);
			}
		}
		// achtunbg: die kleiner zahl muss masgebend sein beim dividieren durch 2
		if(count($catxyprops)>count($testcatprops)){
			if(count($equalprops)>count($testcatprops)/2){
				array_push($result, $vocabcats[$i]);
				array_push($result, $equalprops);
			}
		}
		else{
		if(count($equalprops)>count($catxyprops)/2){
				array_push($result, $vocabcats[$i]);
				array_push($result, $equalprops);
			}
		}
	}
	return $result;
}
function getVocabCatsS($categorypageid, $vocab){
	$dbr = wfGetDB( DB_SLAVE );
	$vocablinks=array();
	$myarray = array();
	if($vocab==""){
		$where = array( 'pl_from' => $categorypageid, 'pl_namespace'=>110 );
		$vocab = $dbr->selectField( 'pagelinks', 'pl_title', $where, $myarray, $myarray );
	}
	$where = array( 'pl_title' => $vocab, 'pl_namespace'=>110 );
	$temp1= $dbr->select( 'pagelinks', 'pl_from', $where, $myarray, $myarray );
	$count= $dbr->selectField( 'pagelinks', 'count(*)', $where, $myarray, $myarray );
	for ($j=0;$j<$count;$j++){
		$tempx= $temp1->fetchRow();
		$from=$tempx['pl_from'];
		$where = array( 'page_id'=>$from );
		$namespace= $dbr->selectField( 'page', 'page_namespace', $where, $myarray, $myarray );
		if($namespace==14&&$from!=$categorypageid)array_push($vocablinks,$tempx['pl_from']);
	}
	return $vocablinks;
}
function getPropsForCatS($categorypageid){
	$dbr = wfGetDB( DB_SLAVE );
	$properties = array();
	$myarray = array();
	$where = array( 'pl_from' => $categorypageid, 'pl_namespace'=>102 );
	$temp1= $dbr->select( 'pagelinks', 'pl_title', $where, $myarray, $myarray );
	$count= $dbr->selectField( 'pagelinks', 'count(*)', $where, $myarray, $myarray );
	for ($j=0;$j<$count;$j++){
		$tempx= $temp1->fetchRow();
		array_push($properties,$tempx['pl_title']);
	}
	return $properties;
}

function getSimilarCategoriesS($pagenum){
	global $wgOut, $wgRequest, $wgServer;
	$myarray = array();
	$options = array();
	$cats = array();
	$catswithsupercats = array();
	$results = array();
	$dbr = wfGetDB( DB_SLAVE );
	$where = array();
	$count = $dbr->selectField( 'category', 'count(*)', $where, __METHOD__, $options );
	$temp1= $dbr->select( 'category', 'cat_title', $where, $myarray, $myarray );
	for ($j=0;$j<$count;$j++){
		$tempx= $temp1->fetchRow();
		$catsall[$j]=$tempx['cat_title'];
	}
	sort($catsall);
	$cats = $catsall;
	$perpage = 250;
	$dropdownpages=count($cats)/$perpage;
	$dropdownform="Page number: ";
	$action = $wgServer;
	$action.="/index.php/Special:CategoriesWithSimilarPropertysets";
	$dropdownform.=<<<END
		<form name="myform" action=$action method="GET">
		<select name="mydropdown" onchange="this.form.submit()">
END;
	for($i=0;$i<$dropdownpages;$i++){
		$num=$i+1;
		if($i==$pagenum)$dropdownform.="<option selected=$i>$num</selected>";
		else $dropdownform.="<option value=$i>$num</option>";
	}
	if($dropdownpages==0)$dropdownform.="<option value=0>1</option>";
	$dropdownform.=<<<END
	</select>
	</form>
	
END;
	$lower=$pagenum*$perpage;
	$upper=$lower+$perpage;
	if($upper>count($cats))$upper=count($cats);
	$wgOut->addHTML($dropdownform);
	$wgOut->addHTML("<hr>");
	$wgOut->addHTML("<ul>");	
	for ($j=$lower;$j<$upper;$j++){	
		$title = str_replace(' ','_',$cats[$j]);
		$where = array('page_namespace'=>14, 'page_title'=>$title);
		$catpageid = $dbr->selectField( 'page', 'page_id', $where, __METHOD__, $options );
		$result =  getSimilarCatsS($catpageid, "");
		if(count($result)>0){
			$wgOut->addHTML("<li>");
			$wgOut->addWikiText("[[:Category:$cats[$j]|$cats[$j]]]");
			$countresult = count($result);
			$wgOut->addHTML("<ul>");
			for ($i=0;$i<$countresult;$i++){
				$id = $result[$i];
				$properties = $result[$i+1];
				$countproperties = count($properties);
				$where = array('page_id' => $id);
				$catpagetitle = $dbr->selectField( 'page', 'page_title', $where, __METHOD__, $options );
				$where = array('smw_title' => $catpagetitle);
				$cat = $dbr->selectField( 'smw_ids', 'smw_sortkey', $where, __METHOD__, $options );
				$wgOut->addHTML("<li>");
				$outstring = "[[:Category:$cat|$cat]] (";
				for ($k=0;$k<$countproperties;$k++){
					$prop = array_pop($properties);
					if ($k!=$countproperties-1) $outstring.="[[:Property:$prop|$prop]], ";
					else $outstring.="[[:Property:$prop|$prop]])";
				}
				$wgOut->addWikiText($outstring); 
				$wgOut->addHTML("</li>");
				$i++;
			}
			$wgOut->addHTML("</ul>");
			$wgOut->addHTML("</li>");
		}
	}
	$wgOut->addHTML("</ul>");
}
