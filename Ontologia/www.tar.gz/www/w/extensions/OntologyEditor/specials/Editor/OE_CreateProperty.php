<?php

if (!defined('MEDIAWIKI')) die();

class OECreateProperty extends SpecialPage {

	/**
	 * Constructor
	 */
	function OECreateProperty() {
		SpecialPage::SpecialPage('CreateProperty');
		wfLoadExtensionMessages('OntologyEditor');
	}

	function execute($query) {
		$this->setHeaders();
		doSpecialCreatePropertyOE();
	}
}

function createPropertyText($property_type, $allowed_values_str) {
	global $smwgContLang;

	wfLoadExtensionMessages('OntologyEditor');

	// handling of special property labels changed in SMW 1.4
	if (method_exists($smwgContLang, 'getPropertyLabels')) {
		$prop_labels = $smwgContLang->getPropertyLabels();
		$type_tag = "[[{$prop_labels['_TYPE']}::$property_type]]";
	} else {
		$spec_props = $smwgContLang->getSpecialPropertiesArray();
		$type_tag = "[[{$spec_props[SMW_SP_HAS_TYPE]}::$property_type]]";
	}
	$text = wfMsgForContent('sf_property_isproperty', $type_tag);
	if ($allowed_values_str != '') {
		$text .= "\n\n" . wfMsgForContent('sf_property_allowedvals');
		// replace the comma substitution character that has no chance of
		// being included in the values list - namely, the ASCII beep
		global $sfgListSeparator;
		$allowed_values_str = str_replace("\\$sfgListSeparator", "\a", $allowed_values_str);
		$allowed_values_array = explode($sfgListSeparator, $allowed_values_str);
		foreach ($allowed_values_array as $i => $value) {
			// replace beep back with comma, trim
			$value = str_replace("\a", $sfgListSeparator, trim($value));
			if (method_exists($smwgContLang, 'getPropertyLabels')) {
				$prop_labels = $smwgContLang->getPropertyLabels();
				$text .= "\n* [[" . $prop_labels['_PVAL'] . "::$value]]";
			} else {
				$spec_props = $smwgContLang->getSpecialPropertiesArray();
				$text .= "\n* [[" . $spec_props[SMW_SP_POSSIBLE_VALUE] . "::$value]]";
			}
		}
	}
	return $text;
}

function doSpecialCreatePropertyOE() {
	global $wgOut, $wgRequest, $sfgScriptPath;
	global $smwgContLang;
	//new
	global $wgUser;
	//end new


	
	wfLoadExtensionMessages('OntologyEditor');


	addCustomScriptsAndStyles();


	$text = "";
	$oc = new OEOntologyCreator();

	# cycle through the query values, setting the appropriate local variables
	$property_name = $wgRequest->getVal('property_name');
	$property_type = $wgRequest->getVal('property_type');
	$property_description = $wgRequest->getVal('property_description');
	$allowed_values = $wgRequest->getVal('values');

	$save_button_text = wfMsg('savearticle');
	$preview_button_text = wfMsg('preview');

	$property_name_error_str = '';
	$save_page = $wgRequest->getCheck('wpSave');
	$preview_page = $wgRequest->getCheck('wpPreview');
	if ($save_page || $preview_page) {
		# validate property name
		if ($property_name == '') {
			$property_name_error_str = wfMsg('sf_blank_error');
		} else {
			# redirect to wiki interface
			/*$wgOut->setArticleBodyOnly(true);
			$title = Title::makeTitleSafe(SMW_NS_PROPERTY, $property_name);
			$full_text = createPropertyText($property_type, $allowed_values);*/
			// HTML-encode
			//$full_text = str_replace('"', '&quot;', $full_text);
			//$text = SFUtils::printRedirectForm($title, $full_text, "", $save_page, $preview_page, false, false, false, null, null);


			//fff
			/*$article = new Article($title);
		      	$article->doEdit($full_text, '');
			$wgOut->addHTML($text);*/
			//$title = Title::makeTitleSafe(SMW_NS_PROPERTY, $property_name);
			$url = $oc->createProperty($property_name, $property_type, $property_description);
			$redirect = $oc->createPageRedirect($url);
			$wgOut->addHTML($redirect);
			return;
		}
	}

	$datatype_labels = $smwgContLang->getDatatypeLabels();

	$javascript_text =<<<END
function toggleAllowedValues() {
	var values_div = document.getElementById("allowed_values");
}

END;

	// set 'title' as hidden field, in case there's no URL niceness
	global $wgContLang;
	$mw_namespace_labels = $wgContLang->getNamespaces();
	$special_namespace = $mw_namespace_labels[NS_SPECIAL];
	$name_label = wfMsg('sf_createproperty_propname');
	$type_label = wfMsg('sf_createproperty_proptype');
	$text =<<<END
	<form action="" method="post">
	<input type="hidden" name="title" value="$special_namespace:CreateProperty">
	<fieldset class="property"><legend>Property Information</legend><table class="formtable"><tr><th><b>$name_label</b></th><td> <input size="25" name="property_name" value="">
	<span style="color: red;">$property_name_error_str</span></td></tr>
	<tr><th><b>$type_label</b></th><td>
	<select id="property_dropdown" name="property_type" onChange="toggleAllowedValues();">
END;
	foreach ($datatype_labels as $label) {
		$text .= "	<option>$label</option>\n";
	}

	//$values_input = wfMsg('sf_createproperty_allowedvalsinput');
//put under "select" below"
/*<div id="allowed_values" style="margin-bottom: 15px;">
	<p>$values_input</p>
	<p><input size="80" name="values" value=""></p>*/


	$text .=<<<END
	</select>
	<br /></td></tr></table><br />

	<p><b>Description:</b></p><textarea tabindex="6" id="free_text" name="property_description" rows="5" cols="80" class="autoexpanding" style="width: 45%;">$property_description</textarea>

	</fieldset>
	<div class="editButtons">
	<input id="wpSave" type="submit" name="wpSave" value="$save_button_text">
	<input id="wpPreview" type="submit" name="wpPreview" value="$preview_button_text">
	</div>
	</form>

END;



        $text .= <<<END
	<script type="text/javascript">
	        var googie1 = new GoogieSpell('/extensions/OntologyEditor/libs/googiespell/', '/extensions/OntologyEditor/libs/googiespell/sendReq.php?lang=');
		        googie1.decorateTextarea("free_text");
		</script>
END;


	/*
	//new
	$sk = $wgUser->getSkin();
	$cc = SpecialPage::getPage('CreateClass');
	$co = SpecialPage::getPage('CreateOntology');
	$create_class_link = $sk->makeKnownLinkObj($cc->getTitle(), $cc->getDescription());
	$create_ontology_link = $sk->makeKnownLinkObj($co->getTitle(), $co->getDescription());
	$text .= "	<br /><hr /><br />\n";
	$text .= "	<p>$create_class_link.</p>\n";
	$text .= "	<p>$create_ontology_link.</p>\n";

	//end new
	*/
	$wgOut->addLink( array(
		'rel' => 'stylesheet',
		'type' => 'text/css',
		'media' => "screen, projection",
		'href' => $sfgScriptPath . "/skins/SF_main.css"
	));
	$wgOut->addScript('<script type="text/javascript">' . $javascript_text . '</script>');
	$wgOut->addHTML($text);
}
