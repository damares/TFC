<?php
if (!defined('MEDIAWIKI')) die();

class OESetup extends SpecialPage {
		
		
        function OESetup() {
                SpecialPage::SpecialPage('OE_Setup');
                wfLoadExtensionMessages('OntologyEditor');
        }

        function execute() {
				doSpecialSetup($vocabulary, $edit);
				displayText();
        }
		

}
function displayText(){
	global $wgOut;
	$wgOut->addHTML(wfMsgExt( 'oe_setuptext', array( 'parse' ) ) 	);
}
function doSpecialSetup() {
	global $wgOut;
	$oc = new OEOntologyCreator();
	// properties
	$full_text = <<<END
This is a property of type [[Has type::text]].
END;
	$oc->performSavePage("HasDescription", $full_text, SMW_NS_PROPERTY);


	$full_text = <<<END
[[has type::String]]
END;
	$oc->performSavePage("HasSynonyms", $full_text, SMW_NS_PROPERTY);


	$full_text = <<<END
[[has type::URL]].
END;
	$oc->performSavePage("HasFlickrImage", $full_text, SMW_NS_PROPERTY);



	$full_text = <<<END
[[has type::String]]
END;
	$oc->performSavePage("HasExampleOfUsage", $full_text, SMW_NS_PROPERTY);


	$full_text = ".";
	$oc->performSavePage("OE_Dummy1", $full_text, NS_CATEGORY);


	$full_text = "[[Category:OE_Dummy1]]";
	$oc->performSavePage("OE_Dummy2", $full_text, NS_CATEGORY);

// sidebar
$full_text = <<<END
* SEARCH
* create
** createvocabulary-url|createvocabulary
** createcategory-url|createcategory
** createproperty-url|createproperty
* import functionalities
** Special:ImportVocabulary|Vocabulary Import
* knowledge repair
** Special:CategoryStatistics|Category Statistics
** Special:CategoriesInCycles|Categories in Cycles
** Special:CategoriesWithRedundantLinks|Redundant Links
** Special:EntitiesWithSimilarNames|Naming Conflicts
** Special:Versioning|Versioning
* mediawiki links
** mainpage|mainpage-description
** helppage|help
** Special:SpecialPages|Special Pages
END;
	$oc->performSavePage("Sidebar", $full_text, NS_MEDIAWIKI);

// main page
$full_text = <<<END
<h1>Vocabulary Editor</h1>
<h2>Community‐based building of lightweight domain vocabularies</h2>
This editor allows building lightweight domain vocabularies in a community‐driven fashion. Find the screencast here (http://members.deri.at/~simonh/semanticMediaWiki/screencast.avi)

The SMW Ontology Editor is a platform for collaborative management of lightweight ontologies for Wiki-communities. It consists of a rich interface which can be used to browse, view, create, delete, change and maintain vocabularies, a bunch of functionalities to check vocabularies for inconsistencies, anomalies and errors as well as functionalities which provide additional information on the entities in the Wiki. Moreover the platform provides vocabulary round tripping (import and export of vocabularies) as well as the import of folksonomies.

You can:

* [[Special:CreateVocabulary|create a vocabulary]], [[Special:CreateCategory|create a category]], [[Special:CreateProperty|create a property]] or you can browse/view already existing entities by using the entity boxes or the tag cloud below,

* [[Special:CategoryStatistics|have a comprehensive view on issues relating all existing categories]], [[Special:CategoryKnowledgeRepair|examine one specific category at a time]] or [[Special:SpecialPages|you can get additional information on the entities in the Wiki (section Knowledge Repair)]],

* [[Special:ImportVocabulary|import a vocabulary]] or you can export a vocabulary by pressing the 'export pages' tab occurring with every vocabulary.


The overview below displays the set of ontology elements within the Wiki. When clicking on the icon <html><img src="/extensions/OntologyEditor/skins/images/folder_explore.png" /></html> displayed next to a vocabulary in the Vocabulary box, the set of categories corresponding to the vocabulary will be displayed dynamically in the Category box.
END;
	$oc->performSavePage("Main_Page", $full_text, NS_MAIN);

// template:classtemplate

$full_text = <<<END
<noinclude>
This is the 'ClassTemplate' template.
It should be called in the following format:
<pre>
{{ClassTemplate
|Vocabulary=
|See Also=
|Synonyms=
|Example Of Usage=
|Properties=
}}
</pre>
Edit the page to see the template text.
</noinclude><includeonly>
<html>
 <div style="width:35%; float:right; margin: 0px 30px 30px 0px; margin-left:30px;">
 <fieldset><legend style="font-size:1.2em;">Relations</legend>
 <ul style="line-height: 2em;">
  <li><img src="/extensions/OntologyEditor/skins/images/v_gold16.png" style="border-width:1px; border-style:solid;" /> <b>Vocabulary:</b> </html>[[HasOntology::{{{Vocabulary|}}}]] <html></li>
  <li><img src="/extensions/OntologyEditor/skins/images/c_blue16.png" style="border-width:1px; border-style:solid;" /> <b>Category:</b> </html>{{#categorytree:{{PAGENAME}}}}<html></li>
  <li><img src="/extensions/OntologyEditor/skins/images/p_violet16.png" style="border-width:1px; border-style:solid;" /> <b>Properties:</b> </html>{{#arraymap:{{{Properties|}}}|,|x|[[HasProperties::x]]}}<html></li>
  <li><img src="/extensions/OntologyEditor/skins/images/e_lg16.png" style="border-width:1px; border-style:solid;" /> <b>Elements:</b> </html>{{#ask: [[Category:{{PAGENAME}}]] | format=list}}<html></li>
 </ul>
 </fieldset>
 <fieldset><legend style="font-size:1.2em;">Information</legend>
 <ul style="line-height: 2em;">
  <li><b>Synonyms:</b> </html>{{#arraymap:{{{Synonyms|}}}|,|x|[[HasSynonyms::x]]}} <html><a href="#editsynonyms" rel="facebox" style="font-size: 75%;">(edit)</a></li>
  <li><b>See Also:</b> </html>[[SeeAlso::{{{See Also|}}}]] <html><a href="#editseealso" rel="facebox" style="font-size: 75%;">(edit)</a></li>
  <li><b>Example Of Usage:</b> </html>[[HasExampleOfUsage::{{{Example Of Usage|}}}]] <html><a href="#editexample" rel="facebox" style="font-size: 75%;">(edit)</a></li>
 </ul>
 </fieldset>
 </div>
</html>
</includeonly>
END;
	$oc->performSavePage("ClassTemplate", $full_text, NS_TEMPLATE);
	
	$dbw = wfGetDB(DB_MASTER);
	
	$catHistSql = 'CREATE TABLE IF NOT EXISTS `smw_cat_history` (
  `history_nr` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `vocabulary` varchar(200) NOT NULL,
  `see_also` varchar(500) NOT NULL,
  `example_of_usage` varchar(1000) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `synonyms` varchar(200) NOT NULL,
  PRIMARY KEY (`history_nr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;';

	$histSql = 'CREATE TABLE IF NOT EXISTS `smw_history` (
  `history_nr` int(20) NOT NULL,
  `change_date` datetime NOT NULL,
  `change_type` varchar(3) NOT NULL,
  `concerning` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;';

	$structHistSql = 'CREATE TABLE IF NOT EXISTS `smw_struct_history` (
  `history_nr` int(10) DEFAULT NULL,
  `cl_from` int(11) DEFAULT NULL,
  `cl_to` varbinary(255) DEFAULT NULL,
  `cl_sortkey` varbinary(70) NOT NULL,
  `cl_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;';

	$dbw->query($catHistSql);
	$dbw->query($histSql);
	$dbw->query($structHistSql);
	

}
