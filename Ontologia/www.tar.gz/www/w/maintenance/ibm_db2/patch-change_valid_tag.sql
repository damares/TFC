CREATE TABLE valid_tag (
  vt_tag varchar(255) NOT NULL PRIMARY KEY
);
