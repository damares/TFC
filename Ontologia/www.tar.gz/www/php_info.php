<?php

// Muestra toda la información, por defecto INFO_ALL
phpinfo();

?>